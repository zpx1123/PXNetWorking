//
//  WDBaseModle.h
//  WDNetWorking
//
//  Created by 周鹏翔 on 15/12/28.
//  Copyright © 2015年 周鹏翔. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WDBaseModle : NSObject
@property(nonatomic,assign)NSInteger  mId;
@property(nonatomic,strong)NSString * mName;
@end
