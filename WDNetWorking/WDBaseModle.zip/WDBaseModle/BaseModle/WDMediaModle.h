//
//  WDMediaModle.h
//  WDNetWorking
//
//  Created by 周鹏翔 on 15/12/28.
//  Copyright © 2015年 周鹏翔. All rights reserved.
//

#import "WDBaseModle.h"

@interface WDMediaModle : WDBaseModle
@property(nonatomic,strong)NSString * mPath;
@property(nonatomic,strong)NSString * mFileSize;
@property(nonatomic,strong)NSString * mDuration;
@property(nonatomic,strong)NSString * mCreatTime;
@end
